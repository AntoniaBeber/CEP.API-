package br.org.fundatec.cep.controller;

import br.org.fundatec.cep.model.Cidade;
import br.org.fundatec.cep.model.Uf;
import br.org.fundatec.cep.repository.CidadeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



@WebMvcTest(CidadeController.class)
public class CidadeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CidadeRepository cidadeRepository;

    private Cidade cidade;

    @BeforeEach
    public void setUp() {
    }
     @Test
     public void testCidade1() {
         Cidade cidade1 = new Cidade("Porto Alegre", new Uf("Rio Grande do Sul", "RS"));
     }

     @Test
     public void testCidade2(){
        Cidade cidade2 = new Cidade("Timbo",new Uf("Santa Catarina", "SC"));
     }

    @Test
    public void testListCidades() throws Exception {
        Mockito.when(cidadeRepository.findAll()).thenReturn(Collections.singletonList(cidade));

        mockMvc.perform(get("/cidades")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nome").value("Porto Alegre"))
                .andExpect(jsonPath("$[0].uf").value("Timbo"));
    }


}
