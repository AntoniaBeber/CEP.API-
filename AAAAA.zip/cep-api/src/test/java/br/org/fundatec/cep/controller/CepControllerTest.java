package br.org.fundatec.cep.controller;

import br.org.fundatec.cep.model.Cep;
import br.org.fundatec.cep.model.Cidade;
import br.org.fundatec.cep.model.Uf;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;

@WebMvcTest(CepController.class)
@AutoConfigureMockMvc
public class CepControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private CepController cepController;

    @Test
    public void testGetAllCeps() throws Exception {
        Cep cep1 = new Cep(91911999, new Cidade("Porto Alegre", new Uf("Rio Grande do Sul", "RS")), "Ceres", 129,180);
        Cep cep2 = new Cep(99999999, new Cidade("Timbo", new Uf("Santa Catarina", "SC")), "Pomeranos", 200,280);

        List<Cep> listaCeps = Arrays.asList(cep1, cep2);

        when(cepController.get()).thenReturn(ResponseEntity.ok(listaCeps));

        mockMvc.perform(MockMvcRequestBuilders.get("/ceps")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].cep").value(91911999))
                .andExpect(MockMvcResultMatchers.jsonPath("$[1].cep").value(99999999));
    }

}