INSERT INTO cep (cep, cidade, uf, logradouro) VALUES (95680808,'Canela', 'RS', 'Rua 1');
