package br.org.fundatec.cep.model;

import br.org.fundatec.cep.annotation.CepValidation;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Objects;

@Entity
@Table(name = "cep")
public class Cep {

    @Id
    @CepValidation(message = "Cep nulo ou em faixa invalida")
    private Integer cep;

    @ManyToOne
    @JoinColumn(name = "id_cidade", nullable = false)
    private Cidade cidade;

    @Column(nullable = false)
    @NotBlank(message = "Logradouro não pode ser nulo")
    private String logradouro;

    @Column(nullable = false)
    @NotNull(message = "Número de início não pode ser nulo")
    private Integer num_inicio;

    @Column(nullable = false)
    @NotNull(message = "Número de fim não pode ser nulo")
    private Integer num_fim;

    public Cep() {
    }

    public Cep(Integer cep, Cidade cidade, String logradouro, Integer num_inicio, Integer num_fim) {
        this.cep = cep;
        this.cidade = cidade;
        this.logradouro = logradouro;
        this.num_inicio = num_inicio;
        this.num_fim = num_fim;
    }

    public Cep(Integer cep, String cidade, String uf, String logradouro) {
    }

    public Integer getCep() {
        return cep;
    }

    public void setCep(Integer cep) {
        this.cep = cep;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public Integer getNum_inicio() {
        return num_inicio;
    }

    public void setNum_inicio(Integer num_inicio) {
        this.num_inicio = num_inicio;
    }

    public Integer getNum_fim() {
        return num_fim;
    }

    public void setNum_fim(Integer num_fim) {
        this.num_fim = num_fim;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cep cep1 = (Cep) o;
        return Objects.equals(cep, cep1.cep);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cep);
    }
}
