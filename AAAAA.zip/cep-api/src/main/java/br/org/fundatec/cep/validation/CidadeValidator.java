package br.org.fundatec.cep.validation;

import br.org.fundatec.cep.annotation.CidadeValidation;
import br.org.fundatec.cep.repository.CidadeRepository;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

public class CidadeValidator implements ConstraintValidator<CidadeValidation, String> {

    @Autowired
    private CidadeRepository cidadeRepository;

    @Override
    public void initialize(CidadeValidation constraintAnnotation) {
        // Inicialização do validador, se necessário
    }

    @Override
    public boolean isValid(String cidadeNome, ConstraintValidatorContext context) {
        // Lógica de validação da cidade
        return cidadeRepository.existsById(cidadeNome);
    }
}
