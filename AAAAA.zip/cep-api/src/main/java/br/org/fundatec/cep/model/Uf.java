package br.org.fundatec.cep.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "Uf")
public class Uf {

    @Id
    @Column(length = 2)
    @NotBlank(message = "UF não pode ser nulo")
    @Size(min = 2, max = 2, message = "UF deve ter exatamente dois caracteres")
    private String uf;

    @Column(nullable = false)
    @NotBlank(message = "Nome não pode ser nulo")
    private String nome_uf;

    @OneToMany(mappedBy = "uf")
    private Set<Cidade> cidades;

    public Uf() {
    }

    public Uf(String nome_uf, String uf) {
        this.nome_uf = nome_uf;
        this.uf = uf;
    }

    public String getNome_uf() {
        return nome_uf;
    }

    public void setNome_uf(String nome_uf) {
        this.nome_uf = nome_uf;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public Set<Cidade> getCidades() {
        return cidades;
    }

    public void setCidades(Set<Cidade> cidades) {
        this.cidades = cidades;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Uf uf1 = (Uf) o;
        return Objects.equals(uf, uf1.uf);
    }

    @Override
    public int hashCode() {
        return Objects.hash(uf);
    }
}
