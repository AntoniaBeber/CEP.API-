package br.org.fundatec.cep.annotation;

import br.org.fundatec.cep.validation.CidadeValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = CidadeValidator.class)
public @interface CidadeValidation {

    Class<?>[] groups() default {};

    String message() default "Cidade inválida";

    Class<? extends Payload>[] payload() default {};
}
