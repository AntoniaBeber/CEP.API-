package br.org.fundatec.cep.validation;

import br.org.fundatec.cep.annotation.UfValidation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.Arrays;
import java.util.List;

public class UfValidator implements ConstraintValidator<UfValidation, String> {

    private static final List<String> UFS_VALIDAS = Arrays.asList("RS", "SC", "PR"); // Exemplo de UFs válidas

    @Override
    public void initialize(UfValidation constraintAnnotation) {
        // Inicialização do validador, se necessário
    }

    @Override
    public boolean isValid(String uf, ConstraintValidatorContext context) {
        // Lógica de validação da UF
        return uf != null && UFS_VALIDAS.contains(uf.toUpperCase());
    }
}
