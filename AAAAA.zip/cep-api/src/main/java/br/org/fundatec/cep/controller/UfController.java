package br.org.fundatec.cep.controller;

import br.org.fundatec.cep.model.Uf;
import br.org.fundatec.cep.repository.UfRepository;
import br.org.fundatec.cep.exception.RegistroNaoEcontradoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ufs")
public class UfController {

    @Autowired
    private UfRepository ufRepository;

    //Cria UF
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Uf> createUf(@RequestBody Uf uf) {
        Uf novaUf = ufRepository.save(uf);
        return ResponseEntity.status(HttpStatus.CREATED).body(novaUf);
    }
    //Lista UF
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Uf>> listUfs() {
        List<Uf> ufs = ufRepository.findAll();
        if (ufs.isEmpty()) {
            throw new RegistroNaoEcontradoException("Nenhuma UF encontrada");
        }
        return ResponseEntity.status(HttpStatus.OK).body(ufs);
    }
    //Reg N Encontrado
    @ExceptionHandler(RegistroNaoEcontradoException.class)
    public ResponseEntity<String> handleRegistroNaoEcontradoException(RegistroNaoEcontradoException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }
}
