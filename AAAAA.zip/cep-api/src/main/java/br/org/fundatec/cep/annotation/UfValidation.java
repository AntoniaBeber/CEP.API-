package br.org.fundatec.cep.annotation;

import br.org.fundatec.cep.validation.UfValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = UfValidator.class)
public @interface UfValidation {

    Class<?>[] groups() default {};

    String message() default "UF inválida";

    Class<? extends Payload>[] payload() default {};
}
