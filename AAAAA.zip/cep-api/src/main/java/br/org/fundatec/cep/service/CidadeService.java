package br.org.fundatec.cep.service;

import br.org.fundatec.cep.exception.RegistroNaoEcontradoException;
import br.org.fundatec.cep.model.Cidade;
import br.org.fundatec.cep.repository.CidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CidadeService {

    @Autowired
    private CidadeRepository cidadeRepository;

    public Cidade salvar(Cidade cidade) {
        return cidadeRepository.save(cidade);
    }

    public Cidade busca(Integer idCidade) {
        Optional<Cidade> busca = cidadeRepository.findById(Long.valueOf(idCidade));
        return busca.orElseThrow(() -> new RegistroNaoEcontradoException("Cidade com ID: " + idCidade + " não encontrada"));
    }

    public List<Cidade> buscaTodos() {
        return cidadeRepository.findAll();
    }

    public List<Cidade> buscaPorUf(String uf) {
        return cidadeRepository.findByUf(uf);
    }

    public void remover(Integer idCidade) {
        Cidade cidade = this.busca(idCidade);
        cidadeRepository.delete(cidade);
    }
}
