package br.org.fundatec.cep.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "Cidade")
public class Cidade {

    @Id
    @Column(name = "id_cidade")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_cidade;

    @Column(nullable = false)
    @NotBlank(message = "Nome não pode ser nulo")
    private String nome;

    @ManyToOne
    @JoinColumn(name = "uf", nullable = false)
    @NotNull(message = "UF não pode ser nulo")
    private Uf uf;

    @OneToMany(mappedBy = "cidade")
    private Set<Cep> ceps;


    public Cidade(String nome, Uf uf) {
        this.nome = nome;
        this.uf = uf;
    }

    public Integer getId_cidade() {
        return id_cidade;
    }

    public void setId_cidade(Integer id_cidade) {
        this.id_cidade = id_cidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Uf getUf() {
        return uf;
    }

    public void setUf(Uf uf) {
        this.uf = uf;
    }

    public Set<Cep> getCeps() {
        return ceps;
    }

    public void setCeps(Set<Cep> ceps) {
        this.ceps = ceps;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cidade cidade = (Cidade) o;
        return Objects.equals(id_cidade, cidade.id_cidade);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id_cidade);
    }
}
