package br.org.fundatec.cep.service;

import br.org.fundatec.cep.exception.RegistroNaoEcontradoException;
import br.org.fundatec.cep.model.Uf;
import br.org.fundatec.cep.repository.UfRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UfService {

    @Autowired
    private UfRepository ufRepository;

    public Uf salvar(Uf uf) {
        return ufRepository.save(uf);
    }

    public Uf busca(String sigla) {
        Optional<Uf> busca = ufRepository.findById(Long.valueOf(sigla));
        return busca.orElseThrow(() -> new RegistroNaoEcontradoException("UF com sigla: " + sigla + " não encontrada"));
    }

    public List<Uf> buscaTodos() {
        return ufRepository.findAll();
    }

    public void remover(String sigla) {
        Uf uf = this.busca(sigla);
        ufRepository.delete(uf);
    }
}
